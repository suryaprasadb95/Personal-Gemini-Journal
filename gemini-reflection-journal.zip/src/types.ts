export type ReflectionMode = 
  | 'reflection'
  | 'brainstorming'
  | 'summary'
  | 'action_plan'
  | 'emotional_resonance'
  | 'straight_rag';

export interface GroundingSource {
  docId: string;
  docTitle: string;
  category?: string;
  snippet: string;
  relevanceScore?: number;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  modelUsed?: string;
  groundingSources?: GroundingSource[];
  isRagGrounded?: boolean;
}

export interface JournalEntry {
  id: string;
  userId: string;
  title: string;
  category: string;
  summary: string;
  tags: string[];
  messages: ChatMessage[];
  mode: ReflectionMode;
  createdAt: string;
  updatedAt: string;
}

export interface InteractionLog {
  id: string;
  userId: string;
  prompt: string;
  response: string;
  mode: ReflectionMode;
  createdAt: string;
  modelUsed?: string;
  ragGrounded?: boolean;
}

export interface KnowledgeDocument {
  id: string;
  userId: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  createdAt: string;
  updatedAt: string;
}

export interface RAGSettings {
  enabled: boolean;
  antiHallucinationStrictness: 'strict' | 'balanced';
  answeringStyle: 'straight_talk' | 'bulleted' | 'concise' | 'standard';
  includeJournalHistory: boolean;
  topK: number;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
}
