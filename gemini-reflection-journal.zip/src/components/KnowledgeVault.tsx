import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Plus,
  BookOpen,
  Trash2,
  Edit3,
  Search,
  Sparkles,
  Zap,
  Sliders,
  CheckCircle2,
  AlertTriangle,
  Info,
  Layers,
  ArrowRight,
  Database
} from 'lucide-react';
import { KnowledgeDocument, RAGSettings, UserProfile } from '../types';
import {
  saveKnowledgeDoc,
  deleteKnowledgeDoc,
  saveRAGSettings,
  fetchRAGSettings
} from '../lib/firebase';

interface KnowledgeVaultProps {
  user: UserProfile;
  documents: KnowledgeDocument[];
  onDocumentsChange: (docs: KnowledgeDocument[]) => void;
  onNavigateToStudio: () => void;
}

export const KnowledgeVault: React.FC<KnowledgeVaultProps> = ({
  user,
  documents,
  onDocumentsChange,
  onNavigateToStudio,
}) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [selectedDoc, setSelectedDoc] = useState<KnowledgeDocument | null>(null);

  // Form State
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('Personal Standards');
  const [tagsInput, setTagsInput] = useState('');
  const [content, setContent] = useState('');
  const [saveLoading, setSaveLoading] = useState(false);
  const [seedLoading, setSeedLoading] = useState(false);
  const [notification, setNotification] = useState<string | null>(null);

  // RAG Settings
  const [ragSettings, setRagSettingsState] = useState<RAGSettings>({
    enabled: true,
    antiHallucinationStrictness: 'strict',
    answeringStyle: 'straight_talk',
    includeJournalHistory: true,
    topK: 4,
  });

  // Test Sandbox State
  const [testQuery, setTestQuery] = useState('');
  const [testLoading, setTestLoading] = useState(false);
  const [retrievedChunks, setRetrievedChunks] = useState<any[] | null>(null);

  useEffect(() => {
    async function loadSettings() {
      try {
        const stored = await fetchRAGSettings(user.uid);
        if (stored) {
          setRagSettingsState(stored);
        }
      } catch (err) {
        console.error('Error loading RAG settings:', err);
      }
    }
    loadSettings();
  }, [user.uid]);

  const handleSaveSettings = async (updated: Partial<RAGSettings>) => {
    const newSettings: RAGSettings = { ...ragSettings, ...updated };
    setRagSettingsState(newSettings);
    try {
      await saveRAGSettings(user.uid, newSettings);
      showNotification('RAG & anti-hallucination settings updated');
    } catch (err) {
      console.error('Failed to save RAG settings:', err);
    }
  };

  const showNotification = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleOpenCreate = () => {
    setSelectedDoc(null);
    setTitle('');
    setCategory('Personal Standards');
    setTagsInput('');
    setContent('');
    setIsEditing(true);
  };

  const handleOpenEdit = (doc: KnowledgeDocument) => {
    setSelectedDoc(doc);
    setTitle(doc.title);
    setCategory(doc.category);
    setTagsInput(doc.tags.join(', '));
    setContent(doc.content);
    setIsEditing(true);
  };

  const handleSaveDocument = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !content.trim()) return;

    setSaveLoading(true);
    try {
      const tags = tagsInput
        .split(',')
        .map(t => t.trim().toLowerCase())
        .filter(Boolean);

      const docId = selectedDoc ? selectedDoc.id : `doc_${Date.now()}`;
      const newDoc: KnowledgeDocument = {
        id: docId,
        userId: user.uid,
        title: title.trim(),
        category: category.trim() || 'General Knowledge',
        tags: tags.length > 0 ? tags : ['knowledge', 'grounding'],
        content: content.trim(),
        createdAt: selectedDoc?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await saveKnowledgeDoc(user.uid, newDoc);

      const updatedList = selectedDoc
        ? documents.map(d => (d.id === newDoc.id ? newDoc : d))
        : [newDoc, ...documents];

      onDocumentsChange(updatedList);
      setIsEditing(false);
      showNotification(`Saved "${newDoc.title}" to Knowledge Vault`);
    } catch (err: any) {
      console.error('Failed to save knowledge document:', err);
      alert('Failed to save document. Please try again.');
    } finally {
      setSaveLoading(false);
    }
  };

  const handleDelete = async (docId: string, docTitle: string) => {
    if (!window.confirm(`Are you sure you want to remove "${docTitle}" from your knowledge base?`)) {
      return;
    }
    try {
      await deleteKnowledgeDoc(user.uid, docId);
      onDocumentsChange(documents.filter(d => d.id !== docId));
      showNotification(`Deleted "${docTitle}"`);
    } catch (err) {
      console.error('Failed to delete document:', err);
      alert('Failed to delete document.');
    }
  };

  const handleSeedSamples = async () => {
    setSeedLoading(true);
    try {
      const res = await fetch('/api/rag/seed-sample');
      const data = await res.json();
      if (Array.isArray(data.documents)) {
        for (const docData of data.documents) {
          const doc: KnowledgeDocument = {
            ...docData,
            userId: user.uid,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          };
          await saveKnowledgeDoc(user.uid, doc);
        }
        // Fetch all fresh docs
        const responseList = [...data.documents.map((d: any) => ({ ...d, userId: user.uid, createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() }))];
        onDocumentsChange(responseList);
        showNotification('Successfully seeded 3 verified knowledge documents!');
      }
    } catch (err) {
      console.error('Failed to seed sample knowledge:', err);
      alert('Could not seed sample documents.');
    } finally {
      setSeedLoading(false);
    }
  };

  const handleRunRetrievalTest = async () => {
    if (!testQuery.trim() || documents.length === 0) return;
    setTestLoading(true);
    try {
      const res = await fetch('/api/rag/retrieve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: testQuery.trim(),
          documents: documents.map(d => ({
            id: d.id,
            title: d.title,
            content: d.content,
            category: d.category,
          })),
          topK: ragSettings.topK || 4,
        }),
      });
      const data = await res.json();
      setRetrievedChunks(data.chunks || []);
    } catch (err) {
      console.error('Error running test retrieval:', err);
    } finally {
      setTestLoading(false);
    }
  };

  const filteredDocs = documents.filter(doc => {
    const q = searchTerm.toLowerCase();
    return (
      doc.title.toLowerCase().includes(q) ||
      doc.content.toLowerCase().includes(q) ||
      doc.category.toLowerCase().includes(q) ||
      doc.tags.some(t => t.toLowerCase().includes(q))
    );
  });

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Toast Notification */}
      {notification && (
        <div className="fixed bottom-6 right-6 z-50 bg-stone-900 text-white px-4 py-2.5 rounded-xl shadow-lg text-xs flex items-center gap-2 animate-fade-in border border-stone-700">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>{notification}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-stone-200">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <h1 className="text-xl sm:text-2xl font-semibold text-stone-900 tracking-tight">
              RAG Knowledge Base & Anti-Hallucination Vault
            </h1>
          </div>
          <p className="text-sm text-stone-600 max-w-2xl">
            Ground Gemini in your verified personal rules, project guidelines, and facts.
            When RAG is enabled, the model is strictly bound to these documents and conditioned to answer directly with zero conversational fluff.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {documents.length === 0 && (
            <button
              id="seed-knowledge-btn"
              onClick={handleSeedSamples}
              disabled={seedLoading}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-medium bg-amber-50 text-amber-900 border border-amber-300 rounded-xl hover:bg-amber-100 transition-colors shadow-xs"
            >
              <Database className="w-3.5 h-3.5 text-amber-700" />
              <span>{seedLoading ? 'Seeding...' : 'Seed Sample Knowledge'}</span>
            </button>
          )}

          <button
            id="add-doc-btn"
            onClick={handleOpenCreate}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-medium bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors shadow-xs"
          >
            <Plus className="w-4 h-4 text-amber-300" />
            <span>Add Knowledge Doc</span>
          </button>
        </div>
      </div>

      {/* Control Strip & RAG Tuning Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 my-6">
        {/* Anti-Hallucination & Straight-Talk Controls */}
        <div className="lg:col-span-1 p-5 rounded-2xl bg-white border border-stone-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <Sliders className="w-4 h-4 text-stone-700" />
                <h3 className="text-sm font-semibold text-stone-900">RAG & Training Directives</h3>
              </div>
              <span className={`text-[10px] uppercase tracking-wider font-bold px-2 py-0.5 rounded-full ${
                ragSettings.enabled ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' : 'bg-stone-100 text-stone-500'
              }`}>
                {ragSettings.enabled ? 'Active' : 'Disabled'}
              </span>
            </div>

            <p className="text-xs text-stone-500 mb-4">
              Configure strict anti-hallucination barriers and direct answering conditioning for Gemini.
            </p>

            <div className="space-y-3 text-xs">
              {/* Grounding Toggle */}
              <label className="flex items-center justify-between p-2.5 rounded-xl bg-stone-50 border border-stone-200/80 cursor-pointer">
                <div>
                  <div className="font-medium text-stone-800">Ground Gemini in Knowledge Base</div>
                  <div className="text-[11px] text-stone-500">Inject verified chunks into prompt context</div>
                </div>
                <input
                  type="checkbox"
                  checked={ragSettings.enabled}
                  onChange={(e) => handleSaveSettings({ enabled: e.target.checked })}
                  className="w-4 h-4 accent-stone-900 rounded"
                />
              </label>

              {/* Answering Style Selector */}
              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Answering Style Conditioning:
                </label>
                <select
                  value={ragSettings.answeringStyle}
                  onChange={(e) => handleSaveSettings({ answeringStyle: e.target.value as any })}
                  className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-400 font-medium text-stone-800"
                >
                  <option value="straight_talk">Direct Straight-Talk (Zero Preamble / First Sentence Answer)</option>
                  <option value="bulleted">High-Density Bulleted Takeaways</option>
                  <option value="concise">Executive Summary (Max 3 Sentences)</option>
                  <option value="standard">Standard Conversational Reflection</option>
                </select>
              </div>

              {/* Anti-Hallucination Strictness */}
              <div>
                <label className="block font-medium text-stone-700 mb-1">
                  Anti-Hallucination Protocol:
                </label>
                <select
                  value={ragSettings.antiHallucinationStrictness}
                  onChange={(e) => handleSaveSettings({ antiHallucinationStrictness: e.target.value as any })}
                  className="w-full px-3 py-1.5 text-xs bg-stone-50 border border-stone-200 rounded-lg focus:outline-none focus:border-stone-400 font-medium text-stone-800"
                >
                  <option value="strict">Strict (Temperature 0.1 • Refuse speculation if facts absent)</option>
                  <option value="balanced">Balanced (Temperature 0.3 • Strict grounding with gentle guidance)</option>
                </select>
              </div>

              {/* Top K Chunks */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-stone-600">Context Chunks Retrieved (Top-K):</span>
                <span className="font-mono font-bold text-stone-900">{ragSettings.topK}</span>
              </div>
            </div>
          </div>

          <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-500">
            <span>Documents in Vault:</span>
            <span className="font-semibold text-stone-900">{documents.length} verified docs</span>
          </div>
        </div>

        {/* Live Retrieval Sandbox / Hallucination Risk Tester */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-white border border-stone-200 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <h3 className="text-sm font-semibold text-stone-900">Retrieval & Hallucination Risk Sandbox</h3>
              </div>
              <span className="text-[11px] text-stone-500">Inspect chunks before prompting</span>
            </div>

            <p className="text-xs text-stone-500 mb-3">
              Test queries against your knowledge base. Verify which exact document chunks are retrieved and whether Gemini has sufficient facts to answer without hallucinating.
            </p>

            <div className="flex gap-2 mb-3">
              <input
                type="text"
                value={testQuery}
                onChange={(e) => setTestQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleRunRetrievalTest()}
                placeholder="e.g., What are my deep work hours? or What is my dietary restriction?"
                className="flex-1 px-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-stone-400 text-stone-800"
              />
              <button
                id="test-retrieval-btn"
                onClick={handleRunRetrievalTest}
                disabled={testLoading || !testQuery.trim() || documents.length === 0}
                className="px-4 py-2 text-xs font-medium bg-stone-900 text-white rounded-xl hover:bg-stone-800 disabled:opacity-50 transition-colors shrink-0"
              >
                {testLoading ? 'Retrieving...' : 'Test Retrieval'}
              </button>
            </div>

            {/* Test Results Display */}
            {retrievedChunks !== null && (
              <div className="p-3 bg-stone-50 rounded-xl border border-stone-200 text-xs">
                <div className="flex items-center justify-between pb-2 mb-2 border-b border-stone-200">
                  <span className="font-medium text-stone-700">
                    Retrieved {retrievedChunks.length} Chunk{retrievedChunks.length === 1 ? '' : 's'}
                  </span>
                  {retrievedChunks.length > 0 && (retrievedChunks[0].relevanceScore || 0) > 0.15 ? (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                      <CheckCircle2 className="w-3 h-3" /> Factual Grounding Verified
                    </span>
                  ) : (
                    <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                      <AlertTriangle className="w-3 h-3" /> Zero Verified Context (Model will refuse speculation)
                    </span>
                  )}
                </div>

                {retrievedChunks.length === 0 ? (
                  <p className="text-stone-500 italic">No matching content found in your knowledge vault.</p>
                ) : (
                  <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                    {retrievedChunks.map((chunk, i) => (
                      <div key={i} className="p-2.5 rounded-lg bg-white border border-stone-200">
                        <div className="flex items-center justify-between text-[11px] font-semibold text-stone-800 mb-1">
                          <span className="truncate max-w-[200px]">{chunk.docTitle}</span>
                          <span className="text-[10px] font-mono bg-stone-100 text-stone-600 px-1.5 py-0.5 rounded">
                            Relevance: {chunk.relevanceScore !== undefined ? chunk.relevanceScore : 'N/A'}
                          </span>
                        </div>
                        <p className="text-[11px] text-stone-600 line-clamp-2">{chunk.text}</p>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}
          </div>

          <div className="mt-4 pt-2 border-t border-stone-100 flex items-center justify-between">
            <span className="text-xs text-stone-500">Ready to converse with grounded Gemini?</span>
            <button
              onClick={onNavigateToStudio}
              className="inline-flex items-center gap-1 text-xs font-semibold text-stone-900 hover:text-amber-700"
            >
              <span>Open Reflection Studio</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Search & Document Count Header */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 mb-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search documents and rules..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-white border border-stone-200 rounded-xl focus:outline-none focus:border-stone-400 text-stone-800"
          />
        </div>

        <div className="text-xs text-stone-500 self-end sm:self-center">
          Showing {filteredDocs.length} of {documents.length} verified knowledge document{documents.length === 1 ? '' : 's'}
        </div>
      </div>

      {/* Document Grid */}
      {filteredDocs.length === 0 ? (
        <div className="text-center py-16 px-4 bg-white rounded-2xl border border-stone-200 shadow-xs">
          <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-400 flex items-center justify-center mx-auto mb-3">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="text-sm font-semibold text-stone-900 mb-1">
            {searchTerm ? 'No matching documents found' : 'Your Knowledge Vault is Empty'}
          </h3>
          <p className="text-xs text-stone-500 max-w-sm mx-auto mb-4">
            {searchTerm
              ? 'Try a different search term or clear the filter.'
              : 'Add your first document or click "Seed Sample Knowledge" to test immediate RAG grounding and anti-hallucination.'}
          </p>
          {!searchTerm && (
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={handleSeedSamples}
                disabled={seedLoading}
                className="px-4 py-2 text-xs font-medium bg-amber-50 text-amber-900 border border-amber-300 rounded-xl hover:bg-amber-100 transition-colors"
              >
                Seed 3 Sample Documents
              </button>
              <button
                onClick={handleOpenCreate}
                className="px-4 py-2 text-xs font-medium bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors"
              >
                Create Custom Document
              </button>
            </div>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredDocs.map((doc) => (
            <div
              key={doc.id}
              className="p-5 rounded-2xl bg-white border border-stone-200 hover:border-stone-300 transition-all shadow-xs flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-stone-100 text-stone-700">
                    {doc.category}
                  </span>
                  <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handleOpenEdit(doc)}
                      title="Edit Document"
                      className="p-1 text-stone-400 hover:text-stone-700 rounded"
                    >
                      <Edit3 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleDelete(doc.id, doc.title)}
                      title="Delete Document"
                      className="p-1 text-stone-400 hover:text-rose-600 rounded"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <h3 className="font-semibold text-stone-900 text-sm mb-2 line-clamp-1">
                  {doc.title}
                </h3>

                <p className="text-xs text-stone-600 line-clamp-4 leading-relaxed mb-4">
                  {doc.content}
                </p>
              </div>

              <div>
                <div className="flex flex-wrap gap-1 mb-3">
                  {doc.tags.map((tag, idx) => (
                    <span
                      key={idx}
                      className="text-[10px] px-1.5 py-0.5 rounded bg-stone-50 text-stone-500 border border-stone-200"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>

                <div className="pt-2 border-t border-stone-100 flex items-center justify-between text-[11px] text-stone-400">
                  <span>{doc.content.length} characters</span>
                  <span>{new Date(doc.updatedAt || doc.createdAt).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create / Edit Document Modal */}
      {isEditing && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white w-full max-w-xl rounded-2xl shadow-xl border border-stone-200 p-6 animate-scale-up">
            <div className="flex items-center justify-between mb-4 pb-3 border-b border-stone-100">
              <h3 className="text-base font-semibold text-stone-900">
                {selectedDoc ? 'Edit Knowledge Document' : 'Add Knowledge Document'}
              </h3>
              <button
                onClick={() => setIsEditing(false)}
                className="text-stone-400 hover:text-stone-600 text-sm font-semibold"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSaveDocument} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Document Title *
                </label>
                <input
                  type="text"
                  required
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g., Deep Work Principles & Daily Commitments"
                  className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-stone-400 text-stone-900"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Category
                  </label>
                  <input
                    type="text"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="e.g., Personal Standards"
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-stone-400 text-stone-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-stone-700 mb-1">
                    Tags (comma separated)
                  </label>
                  <input
                    type="text"
                    value={tagsInput}
                    onChange={(e) => setTagsInput(e.target.value)}
                    placeholder="rules, productivity, focus"
                    className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-stone-400 text-stone-900"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  Content / Knowledge Text *
                </label>
                <textarea
                  required
                  rows={8}
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="Write clear, factual statements, rules, policies, or guidelines. When asked questions, Gemini will retrieve these exact statements to ground its response without hallucinating."
                  className="w-full px-3 py-2 text-xs bg-stone-50 border border-stone-200 rounded-xl focus:outline-none focus:border-stone-400 text-stone-900 font-mono leading-relaxed"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-stone-100">
                <button
                  type="button"
                  onClick={() => setIsEditing(false)}
                  className="px-4 py-2 text-xs font-medium text-stone-600 hover:text-stone-900"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={saveLoading}
                  className="px-4 py-2 text-xs font-medium bg-stone-900 text-white rounded-xl hover:bg-stone-800 disabled:opacity-50 transition-colors"
                >
                  {saveLoading ? 'Saving...' : 'Save Document'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
