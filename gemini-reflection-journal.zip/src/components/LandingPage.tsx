import React, { useState } from 'react';
import { Sparkles, Shield, Database, Cpu, Lock, ArrowRight, CheckCircle2, MessageSquareText, Layers } from 'lucide-react';

interface LandingPageProps {
  onSignIn: () => Promise<void>;
}

export const LandingPage: React.FC<LandingPageProps> = ({ onSignIn }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleLogin = async () => {
    try {
      setLoading(true);
      setError(null);
      await onSignIn();
    } catch (err: any) {
      console.error('Sign in failed:', err);
      setError(err?.message || 'Failed to sign in with Google. Please ensure popups are allowed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col justify-between">
      {/* Header */}
      <header className="max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 py-6 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-stone-900 text-amber-300 flex items-center justify-center shadow-sm">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <span className="font-semibold text-stone-900 tracking-tight text-lg">
              Gemini Reflection
            </span>
            <span className="ml-2 text-xs font-mono bg-stone-200 text-stone-700 px-2 py-0.5 rounded-md">
              v3.6 Flash
            </span>
          </div>
        </div>

        <button
          id="header-sign-in-btn"
          onClick={handleLogin}
          disabled={loading}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-medium bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors shadow-xs disabled:opacity-50"
        >
          {loading ? (
            <span className="inline-flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-amber-300 border-t-transparent rounded-full animate-spin" />
              Signing In...
            </span>
          ) : (
            <>
              <span>Sign In with Google</span>
              <ArrowRight className="w-4 h-4" />
            </>
          )}
        </button>
      </header>

      {/* Main Hero */}
      <main className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-12 text-center flex-1 flex flex-col items-center justify-center">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-50 border border-amber-200/80 text-amber-900 text-xs font-medium mb-6">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          Powered by Gemini 3.6 Flash & Cloud Firestore Isolation
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-stone-900 max-w-3xl leading-[1.15]">
          A mindful conversational journal that reflects with you.
        </h1>

        <p className="mt-6 text-lg sm:text-xl text-stone-600 max-w-2xl leading-relaxed">
          Express your daily thoughts, dilemmas, and aspirations in multi-turn dialogues with Gemini.
          Get instant executive summaries, brainstorming prompts, and action plans—isolated securely to your personal account.
        </p>

        {error && (
          <div className="mt-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm max-w-md text-left">
            <p className="font-semibold">Authentication Notice:</p>
            <p>{error}</p>
          </div>
        )}

        {/* CTA Button */}
        <div className="mt-8 flex flex-col sm:flex-row items-center gap-4">
          <button
            id="hero-sign-in-btn"
            onClick={handleLogin}
            disabled={loading}
            className="w-full sm:w-auto px-8 py-3.5 text-base font-semibold bg-stone-900 text-white rounded-2xl hover:bg-stone-800 transition-all shadow-md hover:shadow-lg flex items-center justify-center gap-3 disabled:opacity-50 group"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path
                fill="#4285F4"
                d="M23.745 12.27c0-.7-.06-1.4-.19-2.07H12v4.51h6.6c-.29 1.52-1.14 2.82-2.4 3.68v3.05h3.88c2.27-2.09 3.665-5.17 3.665-9.17z"
              />
              <path
                fill="#34A853"
                d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.88-3.05c-1.08.72-2.45 1.16-4.05 1.16-3.12 0-5.77-2.1-6.72-4.93H1.25v3.15C3.26 21.36 7.35 24 12 24z"
              />
              <path
                fill="#FBBC05"
                d="M5.28 14.27c-.25-.72-.38-1.49-.38-2.27s.13-1.55.38-2.27V6.58H1.25C.45 8.18 0 10.03 0 12s.45 3.82 1.25 5.42l4.03-3.15z"
              />
              <path
                fill="#EA4335"
                d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.35 0 3.26 2.64 1.25 6.58l4.03 3.15c.95-2.83 3.6-4.98 6.72-4.98z"
              />
            </svg>
            <span>Continue with Google</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        {/* Value Pillars */}
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-4xl text-left">
          <div className="p-6 rounded-2xl bg-white border border-stone-200 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center mb-4">
              <Cpu className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-stone-900 text-base mb-1">
              Gemini 3.6 Flash Reflex
            </h3>
            <p className="text-sm text-stone-600 leading-relaxed">
              Multi-turn conversational reflections with auto-resilient model fallback ladders for zero-downtime journaling.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-stone-200 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-800 flex items-center justify-center mb-4">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-stone-900 text-base mb-1">
              Isolated Firestore Security
            </h3>
            <p className="text-sm text-stone-600 leading-relaxed">
              Strict path-bound Firestore security rules ensure your private entries can only ever be read or written by you.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-white border border-stone-200 shadow-xs">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-800 flex items-center justify-center mb-4">
              <Layers className="w-5 h-5" />
            </div>
            <h3 className="font-semibold text-stone-900 text-base mb-1">
              Synthesized Summaries
            </h3>
            <p className="text-sm text-stone-600 leading-relaxed">
              Automated executive distillations, category classification, and keyword tags for searchable personal knowledge.
            </p>
          </div>
        </div>

        {/* Security / Privacy Badge */}
        <div className="mt-12 flex items-center gap-2 text-xs text-stone-500">
          <Lock className="w-3.5 h-3.5 text-stone-400" />
          <span>Federated OAuth 2.0 • No Passwords Stored • End-to-End User Isolation</span>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 py-6 text-center text-xs text-stone-500">
        Gemini Reflection Journal &copy; {new Date().getFullYear()} • Built with Google AI Studio & Cloud Firestore
      </footer>
    </div>
  );
};
