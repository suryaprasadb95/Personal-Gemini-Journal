import React, { useState, useRef, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import {
  Send,
  Sparkles,
  Save,
  Check,
  RefreshCw,
  Copy,
  Lightbulb,
  Target,
  HeartHandshake,
  FileText,
  AlertCircle,
  Clock,
  Tag,
  FolderOpen,
  ShieldCheck,
  Zap,
  BookOpen,
  ChevronDown,
  ChevronUp,
  Sliders,
  ExternalLink
} from 'lucide-react';
import { ChatMessage, JournalEntry, ReflectionMode, UserProfile, KnowledgeDocument, GroundingSource } from '../types';
import { saveJournalEntry, saveInteractionLog } from '../lib/firebase';

interface ReflectionStudioProps {
  user: UserProfile;
  activeEntry: JournalEntry | null;
  knowledgeDocs?: KnowledgeDocument[];
  onEntrySaved: (entry: JournalEntry) => void;
  onStartNew: () => void;
  onNavigateToVault?: () => void;
}

const MODES: { id: ReflectionMode; label: string; icon: React.FC<{ className?: string }>; desc: string }[] = [
  {
    id: 'straight_rag',
    label: 'Straight Talk & RAG Grounding',
    icon: ShieldCheck,
    desc: 'Strictly grounded in your verified knowledge vault. Answers directly in the first sentence with zero filler.'
  },
  {
    id: 'reflection',
    label: 'Deep Reflection',
    icon: Lightbulb,
    desc: 'Unpack your thoughts, examine perspectives, and find clarity.'
  },
  {
    id: 'brainstorming',
    label: 'Brainstorming & Ideas',
    icon: Sparkles,
    desc: 'Explore creative angles, divergent solutions, and possibilities.'
  },
  {
    id: 'action_plan',
    label: 'Goals & Action Plan',
    icon: Target,
    desc: 'Transform insights into structured SMART action steps.'
  },
  {
    id: 'emotional_resonance',
    label: 'Emotional Deep Dive',
    icon: HeartHandshake,
    desc: 'Validate feelings, process tension, and foster self-compassion.'
  },
  {
    id: 'summary',
    label: 'Executive Synthesis',
    icon: FileText,
    desc: 'Distill and synthesize core takeaways and key decisions.'
  },
];

const STARTER_PROMPTS: Record<ReflectionMode, string[]> = {
  straight_rag: [
    'What are my daily deep work rules and shutdown rituals?',
    'What are my project architecture standards?',
    'What is my dietary constraint and reading commitment?',
    'What is my secret code? (Anti-Hallucination test: should refuse to fabricate)'
  ],
  reflection: [
    'What was the most challenging moment today, and what did it reveal to me?',
    'What am I currently avoiding, and what would happen if I addressed it?',
    'How have my priorities shifted over the past few weeks?'
  ],
  brainstorming: [
    'I want to brainstorm creative solutions for a project I feel stuck on...',
    'What are 5 unconventional ways I could approach my current workflow?',
    'Help me generate ideas for learning a new high-impact skill this month.'
  ],
  action_plan: [
    'I have a big goal to achieve. Help me break it down into milestones for this week.',
    'How do I structure a realistic daily morning routine that I will actually stick to?',
    'Help me prioritize my top 3 commitments for the upcoming sprint.'
  ],
  emotional_resonance: [
    'I am feeling overwhelmed by recent changes. Help me process these feelings.',
    'How can I practice self-compassion while holding myself to high standards?',
    'I felt an unexpected wave of frustration earlier. Let us unpack why.'
  ],
  summary: [
    'Summarize my main reflections today into core life lessons.',
    'Extract key action points and emotional milestones from our discussion.',
    'Synthesize this into a structured 3-part reflection record.'
  ]
};

export const ReflectionStudio: React.FC<ReflectionStudioProps> = ({
  user,
  activeEntry,
  knowledgeDocs = [],
  onEntrySaved,
  onStartNew,
  onNavigateToVault,
}) => {
  const [messages, setMessages] = useState<ChatMessage[]>(activeEntry?.messages || []);
  const [inputMessage, setInputMessage] = useState('');
  const [topic, setTopic] = useState(activeEntry?.title || '');
  const [mode, setMode] = useState<ReflectionMode>(activeEntry?.mode || 'straight_rag');
  const [isRagActive, setIsRagActive] = useState(true);
  const [answeringStyle, setAnsweringStyle] = useState<'straight_talk' | 'bulleted' | 'concise' | 'standard'>('straight_talk');
  const [expandedSourcesMsgId, setExpandedSourcesMsgId] = useState<string | null>(null);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saveStatus, setSaveStatus] = useState<'idle' | 'saved' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [summaryData, setSummaryData] = useState<{
    title: string;
    summary: string;
    category: string;
    tags: string[];
  } | null>(
    activeEntry
      ? {
          title: activeEntry.title,
          summary: activeEntry.summary,
          category: activeEntry.category,
          tags: activeEntry.tags,
        }
      : null
  );

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (activeEntry) {
      setMessages(activeEntry.messages);
      setTopic(activeEntry.title);
      setMode(activeEntry.mode);
      setSummaryData({
        title: activeEntry.title,
        summary: activeEntry.summary,
        category: activeEntry.category,
        tags: activeEntry.tags,
      });
      setSaveStatus('saved');
    }
  }, [activeEntry]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSendMessage = async (customPrompt?: string) => {
    const textToSend = (customPrompt || inputMessage).trim();
    if (!textToSend || loading) return;

    const userMessage: ChatMessage = {
      id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      role: 'user',
      content: textToSend,
      timestamp: new Date().toISOString(),
    };

    const newMessages = [...messages, userMessage];
    setMessages(newMessages);
    if (!customPrompt) setInputMessage('');
    setLoading(true);
    setErrorMessage(null);
    setSaveStatus('idle');

    try {
      const response = await fetch('/api/gemini/reflect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: newMessages.map((m) => ({ role: m.role, content: m.content })),
          mode,
          topic: topic.trim(),
          ragEnabled: isRagActive || mode === 'straight_rag',
          ragDocuments: knowledgeDocs.map(d => ({
            id: d.id,
            title: d.title,
            content: d.content,
            category: d.category,
          })),
          ragSettings: {
            answeringStyle: mode === 'straight_rag' ? 'straight_talk' : answeringStyle,
            antiHallucinationStrictness: 'strict',
            topK: 4,
          }
        }),
      });

      if (!response.ok) {
        const errData = await response.json().catch(() => ({}));
        throw new Error(errData.error || `Server returned error status ${response.status}`);
      }

      const data = await response.json();
      const assistantMessage: ChatMessage = {
        id: `msg-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        role: 'assistant',
        content: data.reply,
        timestamp: data.timestamp || new Date().toISOString(),
        modelUsed: data.modelUsed,
        groundingSources: data.groundingSources,
        isRagGrounded: data.isRagGrounded,
      };

      const updatedWithAI = [...newMessages, assistantMessage];
      setMessages(updatedWithAI);

      // Log interaction to Firestore
      try {
        await saveInteractionLog(user.uid, {
          id: `int-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
          userId: user.uid,
          prompt: textToSend,
          response: data.reply,
          mode,
          createdAt: new Date().toISOString(),
          modelUsed: data.modelUsed,
          ragGrounded: Boolean(data.isRagGrounded),
        });
      } catch (logErr) {
        console.warn('Non-blocking interaction log failed:', logErr);
      }
    } catch (err: any) {
      console.error('Failed to communicate with Gemini:', err);
      setErrorMessage(err.message || 'Failed to generate response. Please check your connection and retry.');
    } finally {
      setLoading(false);
    }
  };

  const handleSaveToFirestore = async () => {
    if (messages.length === 0) {
      setErrorMessage('Write at least one reflection message before saving to Firestore.');
      return;
    }

    setSaving(true);
    setSaveStatus('idle');
    setErrorMessage(null);

    try {
      let currentSummary = summaryData;
      if (!currentSummary) {
        try {
          const sumRes = await fetch('/api/gemini/summarize', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              messages: messages.map((m) => ({ role: m.role, content: m.content })),
            }),
          });
          if (sumRes.ok) {
            const sumResult = await sumRes.json();
            currentSummary = {
              title: topic.trim() || sumResult.title || 'Personal Reflection',
              summary: sumResult.summary || 'A thoughtful personal reflection session.',
              category: sumResult.category || 'Personal Growth',
              tags: sumResult.tags || ['reflection'],
            };
            setSummaryData(currentSummary);
          }
        } catch (sumErr) {
          console.warn('Summary generation fallback:', sumErr);
        }
      }

      const entryId = activeEntry?.id || `entry-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
      const entryTitle = topic.trim() || currentSummary?.title || 'Daily Journal Reflection';
      const entryToSave: JournalEntry = {
        id: entryId,
        userId: user.uid,
        title: entryTitle,
        category: currentSummary?.category || 'Personal Growth',
        summary: currentSummary?.summary || messages[0]?.content.slice(0, 150) + '...',
        tags: currentSummary?.tags || ['journal', mode],
        messages,
        mode,
        createdAt: activeEntry?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      await saveJournalEntry(user.uid, entryToSave);
      setSaveStatus('saved');
      onEntrySaved(entryToSave);
    } catch (err: any) {
      console.error('Failed to save to Firestore:', err);
      setSaveStatus('error');
      setErrorMessage(err.message || 'Database write error. Click "Retry Save" to persist your reflection.');
    } finally {
      setSaving(false);
    }
  };

  const handleCopyMessage = (content: string, id: string) => {
    navigator.clipboard.writeText(content);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const toggleExpandSources = (msgId: string) => {
    setExpandedSourcesMsgId(prev => prev === msgId ? null : msgId);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 flex flex-col gap-6">
      {/* Studio Header & Mode Selector */}
      <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-stone-100">
          <div>
            <h2 className="text-xl font-bold text-stone-900 flex items-center gap-2">
              <span>Reflection Studio & Grounded Chat</span>
              <span className="text-xs font-mono font-normal bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md">
                Gemini 3.6 Flash
              </span>
            </h2>
            <p className="text-xs text-stone-500 mt-0.5">
              Converse with Gemini using verified knowledge grounding and straight-talk directives.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="studio-new-btn"
              onClick={onStartNew}
              className="px-3 py-1.5 text-xs font-medium text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded-xl transition-colors flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Reset / New</span>
            </button>

            <button
              id="studio-save-btn"
              onClick={handleSaveToFirestore}
              disabled={saving || messages.length === 0}
              className={`px-4 py-1.5 text-xs sm:text-sm font-medium rounded-xl transition-all flex items-center gap-2 shadow-xs ${
                saveStatus === 'saved'
                  ? 'bg-emerald-50 text-emerald-800 border border-emerald-300'
                  : 'bg-stone-900 hover:bg-stone-800 text-white disabled:opacity-40'
              }`}
            >
              {saving ? (
                <>
                  <span className="w-3.5 h-3.5 border-2 border-amber-300 border-t-transparent rounded-full animate-spin" />
                  <span>Saving to Firestore...</span>
                </>
              ) : saveStatus === 'saved' ? (
                <>
                  <Check className="w-4 h-4 text-emerald-600" />
                  <span>Saved in Firestore</span>
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 text-amber-300" />
                  <span>Save Reflection</span>
                </>
              )}
            </button>
          </div>
        </div>

        {/* Reflection Mode Chips */}
        <div className="pt-4 flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          {MODES.map((m) => {
            const Icon = m.icon;
            const isSelected = mode === m.id;
            return (
              <button
                key={m.id}
                id={`mode-chip-${m.id}`}
                onClick={() => setMode(m.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-medium whitespace-nowrap transition-all flex items-center gap-1.5 border ${
                  isSelected
                    ? 'bg-stone-900 text-white border-stone-900 shadow-xs'
                    : 'bg-stone-50 text-stone-600 border-stone-200 hover:bg-stone-100 hover:text-stone-900'
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${isSelected ? 'text-amber-300' : 'text-stone-500'}`} />
                <span>{m.label}</span>
              </button>
            );
          })}
        </div>

        {/* RAG Grounding & Straight-Talk Ribbon */}
        <div className="mt-4 pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3 text-xs bg-stone-50/80 p-3 rounded-xl border border-stone-200/60">
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsRagActive(!isRagActive)}
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg font-medium transition-colors border ${
                isRagActive || mode === 'straight_rag'
                  ? 'bg-emerald-100/80 text-emerald-900 border-emerald-300'
                  : 'bg-stone-200 text-stone-600 border-stone-300'
              }`}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
              <span>RAG Grounding: {isRagActive || mode === 'straight_rag' ? 'ON' : 'OFF'}</span>
            </button>

            <span className="text-stone-500 text-[11px] hidden sm:inline">
              ({knowledgeDocs.length} verified doc{knowledgeDocs.length === 1 ? '' : 's'} available)
            </span>

            {onNavigateToVault && (
              <button
                onClick={onNavigateToVault}
                className="text-[11px] text-stone-600 hover:text-stone-900 font-semibold underline underline-offset-2 flex items-center gap-1"
              >
                <span>Edit Vault</span>
                <ExternalLink className="w-2.5 h-2.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-medium text-stone-500">Style:</span>
            <select
              value={mode === 'straight_rag' ? 'straight_talk' : answeringStyle}
              disabled={mode === 'straight_rag'}
              onChange={(e) => setAnsweringStyle(e.target.value as any)}
              className="bg-white border border-stone-200 rounded-lg px-2 py-1 text-xs text-stone-800 font-medium focus:outline-none"
            >
              <option value="straight_talk">Direct Straight-Talk (First sentence answer)</option>
              <option value="bulleted">Crisp Bullet Points</option>
              <option value="concise">Executive Conciseness</option>
              <option value="standard">Standard Tone</option>
            </select>
          </div>
        </div>

        {/* Optional Title/Topic input */}
        <div className="mt-3 pt-3 border-t border-stone-100 flex items-center gap-3">
          <label htmlFor="topic-input" className="text-xs font-semibold text-stone-500 whitespace-nowrap">
            Topic / Focus:
          </label>
          <input
            id="topic-input"
            type="text"
            placeholder="e.g. Navigating career transition, Productivity rules, Architecture review..."
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            className="flex-1 text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-xl px-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-stone-400 focus:bg-white text-stone-900"
          />
        </div>
      </div>

      {/* Summary Banner if present */}
      {summaryData && (
        <div className="bg-amber-50/60 border border-amber-200/70 rounded-2xl p-4 text-xs sm:text-sm text-stone-800 flex flex-col gap-2">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-amber-900 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-amber-600" />
              Executive AI Synthesis: {summaryData.title}
            </span>
            <span className="px-2 py-0.5 bg-amber-100/80 text-amber-900 rounded-md font-medium text-[11px]">
              {summaryData.category}
            </span>
          </div>
          <p className="text-stone-700 leading-relaxed">{summaryData.summary}</p>
          <div className="flex items-center gap-1.5 flex-wrap pt-1">
            {summaryData.tags.map((t, idx) => (
              <span
                key={idx}
                className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-amber-200 text-stone-600 text-[11px]"
              >
                <Tag className="w-2.5 h-2.5 text-amber-600" />
                {t}
              </span>
            ))}
          </div>
        </div>
      )}

      {/* Error / Retry Banner */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-start justify-between gap-3">
          <div className="flex items-start gap-2">
            <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold">Notice:</p>
              <p className="text-xs sm:text-sm mt-0.5">{errorMessage}</p>
            </div>
          </div>
          <button
            id="retry-save-btn"
            onClick={handleSaveToFirestore}
            className="px-3 py-1 bg-rose-600 text-white text-xs font-semibold rounded-lg hover:bg-rose-700 transition-colors shrink-0"
          >
            Retry Save
          </button>
        </div>
      )}

      {/* Messages Canvas */}
      <div className="bg-white rounded-2xl border border-stone-200 p-5 sm:p-6 min-h-[380px] flex flex-col justify-between shadow-xs">
        {messages.length === 0 ? (
          <div className="py-8 text-center flex flex-col items-center justify-center max-w-lg mx-auto">
            <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-600 flex items-center justify-center mb-3">
              {mode === 'straight_rag' ? (
                <ShieldCheck className="w-6 h-6 text-emerald-700" />
              ) : (
                <Lightbulb className="w-6 h-6 text-amber-600" />
              )}
            </div>
            <h3 className="font-bold text-stone-900 text-lg">
              {mode === 'straight_rag' ? 'Grounded Straight-Talk Session' : 'Begin Your Multi-Turn Reflection'}
            </h3>
            <p className="text-xs sm:text-sm text-stone-500 mt-1 mb-5 leading-relaxed">
              {mode === 'straight_rag'
                ? 'Ask direct questions against your knowledge base. The model will cite exact sources, deliver first-sentence direct answers, and refuse to hallucinate.'
                : 'Express your feelings, ask for constructive reframing, or tap a starter reflection below to converse with Gemini.'}
            </p>

            {/* Starter Prompts */}
            <div className="w-full flex flex-col gap-2 text-left">
              <span className="text-[11px] font-semibold uppercase tracking-wider text-stone-400">
                Suggested Prompts for {MODES.find((m) => m.id === mode)?.label}:
              </span>
              {STARTER_PROMPTS[mode].map((prompt, idx) => (
                <button
                  key={idx}
                  id={`starter-prompt-${idx}`}
                  onClick={() => handleSendMessage(prompt)}
                  className="p-3 text-xs bg-stone-50 hover:bg-stone-100 border border-stone-200 rounded-xl text-stone-700 hover:text-stone-900 text-left transition-colors flex items-start gap-2 group"
                >
                  <Sparkles className="w-3.5 h-3.5 text-amber-600 shrink-0 mt-0.5 group-hover:scale-110 transition-transform" />
                  <span>"{prompt}"</span>
                </button>
              ))}
            </div>
          </div>
        ) : (
          <div className="flex flex-col gap-5 overflow-y-auto max-h-[550px] pr-1">
            {messages.map((msg) => {
              const isRefusal = msg.content.includes('no factual information is available') ||
                msg.content.includes('verified knowledge base');
              const hasSources = msg.groundingSources && msg.groundingSources.length > 0;
              const isSourcesExpanded = expandedSourcesMsgId === msg.id;

              return (
                <div
                  key={msg.id}
                  className={`flex flex-col ${
                    msg.role === 'user' ? 'items-end' : 'items-start'
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1 px-1">
                    <span className="text-[11px] font-medium text-stone-400">
                      {msg.role === 'user' ? 'You' : 'Gemini 3.6 Flash'}
                    </span>
                    <span className="text-[10px] text-stone-300">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    {msg.modelUsed && (
                      <span className="text-[9px] font-mono px-1.5 py-0.2 bg-stone-100 text-stone-600 rounded">
                        {msg.modelUsed}
                      </span>
                    )}
                    {msg.isRagGrounded && (
                      <span className="text-[9px] font-medium px-1.5 py-0.2 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded flex items-center gap-1">
                        <ShieldCheck className="w-2.5 h-2.5" />
                        RAG Grounded
                      </span>
                    )}
                  </div>

                  <div
                    className={`max-w-[85%] sm:max-w-[78%] rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                      msg.role === 'user'
                        ? 'bg-stone-900 text-white rounded-tr-xs'
                        : 'bg-stone-100 text-stone-900 border border-stone-200/80 rounded-tl-xs'
                    }`}
                  >
                    {msg.role === 'user' ? (
                      <p className="whitespace-pre-wrap">{msg.content}</p>
                    ) : (
                      <div className="prose prose-stone prose-sm max-w-none">
                        <ReactMarkdown>{msg.content}</ReactMarkdown>
                      </div>
                    )}
                  </div>

                  {/* Anti-Hallucination Barrier Badge */}
                  {msg.role === 'assistant' && isRefusal && (
                    <div className="mt-1.5 max-w-[85%] sm:max-w-[78%] px-3 py-1.5 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-[11px] flex items-center gap-2">
                      <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                      <span>
                        <strong>Anti-Hallucination Protocol Enforced:</strong> Gemini verified that this information is absent from your knowledge vault and strictly refused to guess or fabricate facts.
                      </span>
                    </div>
                  )}

                  {/* Grounding Sources Inspection Drawer */}
                  {msg.role === 'assistant' && hasSources && (
                    <div className="mt-1.5 max-w-[85%] sm:max-w-[78%] w-full">
                      <button
                        onClick={() => toggleExpandSources(msg.id)}
                        className="w-full text-left p-2 rounded-xl bg-stone-50 hover:bg-stone-100 border border-stone-200 text-[11px] text-stone-700 flex items-center justify-between transition-colors"
                      >
                        <div className="flex items-center gap-1.5">
                          <BookOpen className="w-3.5 h-3.5 text-amber-700" />
                          <span className="font-semibold">
                            Grounding Evidence ({msg.groundingSources?.length} verified chunk{msg.groundingSources?.length === 1 ? '' : 's'} retrieved)
                          </span>
                        </div>
                        {isSourcesExpanded ? (
                          <ChevronUp className="w-3.5 h-3.5 text-stone-400" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5 text-stone-400" />
                        )}
                      </button>

                      {isSourcesExpanded && (
                        <div className="p-3 bg-white rounded-xl border border-stone-200 mt-1 space-y-2 text-xs">
                          {msg.groundingSources?.map((src, i) => (
                            <div key={i} className="p-2.5 rounded-lg bg-stone-50 border border-stone-200/80">
                              <div className="flex items-center justify-between text-[11px] font-semibold text-stone-900 mb-1">
                                <span>{src.docTitle}</span>
                                {src.relevanceScore !== undefined && (
                                  <span className="text-[10px] font-mono text-stone-500 bg-white px-1.5 py-0.5 rounded border border-stone-200">
                                    Relevance: {src.relevanceScore}
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-stone-600 font-mono italic">
                                "{src.snippet}"
                              </p>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Message action strip */}
                  <div className="mt-1 flex items-center gap-2 px-1">
                    <button
                      onClick={() => handleCopyMessage(msg.content, msg.id)}
                      className="text-[11px] text-stone-400 hover:text-stone-600 flex items-center gap-1 transition-colors"
                    >
                      {copiedId === msg.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-600" />
                          <span className="text-emerald-600">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}

            {loading && (
              <div className="flex flex-col items-start">
                <div className="flex items-center gap-2 mb-1 px-1">
                  <span className="text-[11px] font-medium text-stone-400">Gemini Reflex</span>
                </div>
                <div className="bg-stone-100 border border-stone-200 rounded-2xl rounded-tl-xs px-4 py-3 text-stone-600 text-sm flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse delay-75" />
                  <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse delay-150" />
                  <span className="text-xs text-stone-500 ml-1">
                    {mode === 'straight_rag'
                      ? 'Retrieving verified chunks & grounding answer...'
                      : 'Reflecting and synthesizing...'}
                  </span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>
        )}

        {/* Input Bar */}
        <div className="mt-4 pt-4 border-t border-stone-100 flex flex-col gap-2">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              id="reflection-input"
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder={
                mode === 'straight_rag'
                  ? 'Ask a direct factual question against your knowledge base (or test hallucination)...'
                  : `Write a reflection or reply in "${MODES.find((m) => m.id === mode)?.label}" mode...`
              }
              disabled={loading}
              className="flex-1 bg-stone-50 border border-stone-200 rounded-xl px-4 py-3 text-sm text-stone-900 focus:outline-none focus:ring-2 focus:ring-stone-400 focus:bg-white transition-all disabled:opacity-60"
            />
            <button
              id="reflection-send-btn"
              type="submit"
              disabled={loading || !inputMessage.trim()}
              className="p-3 bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors disabled:opacity-40 shadow-xs flex items-center justify-center shrink-0"
            >
              <Send className="w-4 h-4 text-amber-300" />
            </button>
          </form>

          <div className="flex items-center justify-between text-[11px] text-stone-400 px-1">
            <span>
              {mode === 'straight_rag'
                ? 'Strict Anti-Hallucination & Straight Talk Active'
                : 'Multi-turn conversational memory active'}
            </span>
            <span>Isolated to Firestore ID: {user.uid.slice(0, 8)}...</span>
          </div>
        </div>
      </div>
    </div>
  );
};

