import React from 'react';
import { UserProfile } from '../types';
import { Sparkles, LogOut, BookOpen, PlusCircle, ShieldCheck } from 'lucide-react';

interface NavbarProps {
  user: UserProfile | null;
  onSignOut: () => void;
  onNewReflection: () => void;
  activeView: 'studio' | 'knowledge' | 'history';
  setActiveView: (view: 'studio' | 'knowledge' | 'history') => void;
  entryCount: number;
  docCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  user,
  onSignOut,
  onNewReflection,
  activeView,
  setActiveView,
  entryCount,
  docCount = 0,
}) => {
  return (
    <header className="sticky top-0 z-30 bg-white/90 backdrop-blur-md border-b border-stone-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-stone-900 text-amber-300 flex items-center justify-center shadow-sm">
            <Sparkles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-semibold text-stone-900 tracking-tight text-lg">
                Gemini Reflection
              </span>
              <span className="hidden sm:inline-flex items-center gap-1 text-[11px] font-medium bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded-full border border-emerald-200">
                <ShieldCheck className="w-3 h-3" />
                Firestore Isolated
              </span>
            </div>
            <p className="text-xs text-stone-500 hidden md:block">
              Gemini 3.6 Flash • RAG Grounding & Anti-Hallucination
            </p>
          </div>
        </div>

        {user && (
          <div className="flex items-center gap-2 sm:gap-4">
            {/* View Switcher */}
            <div className="flex items-center p-1 bg-stone-100 rounded-xl">
              <button
                id="nav-studio-btn"
                onClick={() => {
                  setActiveView('studio');
                }}
                className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all ${
                  activeView === 'studio'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                Studio
              </button>
              <button
                id="nav-knowledge-btn"
                onClick={() => {
                  setActiveView('knowledge');
                }}
                className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                  activeView === 'knowledge'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                <span>Vault (RAG)</span>
                <span className="ml-0.5 px-1.5 py-0.2 bg-stone-200 text-stone-700 text-[10px] rounded-full font-mono">
                  {docCount}
                </span>
              </button>
              <button
                id="nav-history-btn"
                onClick={() => {
                  setActiveView('history');
                }}
                className={`px-3 py-1.5 text-xs sm:text-sm font-medium rounded-lg transition-all flex items-center gap-1.5 ${
                  activeView === 'history'
                    ? 'bg-white text-stone-900 shadow-xs'
                    : 'text-stone-600 hover:text-stone-900'
                }`}
              >
                <BookOpen className="w-3.5 h-3.5" />
                <span>History</span>
                <span className="ml-0.5 px-1.5 py-0.2 bg-stone-200 text-stone-700 text-[10px] rounded-full font-mono">
                  {entryCount}
                </span>
              </button>
            </div>

            <button
              id="nav-new-entry-btn"
              onClick={onNewReflection}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 text-xs sm:text-sm font-medium bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors shadow-xs"
            >
              <PlusCircle className="w-4 h-4 text-amber-300" />
              <span className="hidden sm:inline">New Entry</span>
            </button>

            {/* User Profile Pill */}
            <div className="flex items-center gap-2 pl-2 border-l border-stone-200">
              {user.photoURL ? (
                <img
                  src={user.photoURL}
                  alt={user.displayName || 'User Avatar'}
                  className="w-8 h-8 rounded-full border border-stone-300 object-cover"
                  referrerPolicy="no-referrer"
                />
              ) : (
                <div className="w-8 h-8 rounded-full bg-stone-200 text-stone-700 font-semibold text-xs flex items-center justify-center">
                  {(user.displayName || user.email || 'U').charAt(0).toUpperCase()}
                </div>
              )}
              <div className="hidden lg:block text-left">
                <div className="text-xs font-semibold text-stone-900 max-w-[130px] truncate">
                  {user.displayName || 'Authenticated User'}
                </div>
                <div className="text-[10px] text-stone-500 max-w-[130px] truncate">
                  {user.email}
                </div>
              </div>
              <button
                id="nav-sign-out-btn"
                onClick={onSignOut}
                title="Sign Out"
                className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-stone-100 transition-colors"
              >
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        )}
      </div>
    </header>
  );
};
