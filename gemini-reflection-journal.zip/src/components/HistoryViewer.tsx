import React, { useState } from 'react';
import {
  Search,
  BookOpen,
  Calendar,
  Tag,
  Trash2,
  ExternalLink,
  Download,
  Filter,
  Layers,
  MessageSquare,
  Sparkles
} from 'lucide-react';
import { JournalEntry, UserProfile } from '../types';
import { deleteJournalEntry } from '../lib/firebase';

interface HistoryViewerProps {
  user: UserProfile;
  entries: JournalEntry[];
  onSelectEntry: (entry: JournalEntry) => void;
  onNewEntry: () => void;
}

export const HistoryViewer: React.FC<HistoryViewerProps> = ({
  user,
  entries,
  onSelectEntry,
  onNewEntry,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  const categories = ['all', ...Array.from(new Set(entries.map((e) => e.category).filter(Boolean)))];

  const filteredEntries = entries.filter((entry) => {
    const matchesSearch =
      entry.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      entry.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (entry.tags && entry.tags.some((t) => t.toLowerCase().includes(searchQuery.toLowerCase()))) ||
      entry.messages.some((m) => m.content.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesCategory = selectedCategory === 'all' || entry.category === selectedCategory;

    return matchesSearch && matchesCategory;
  });

  const handleDelete = async (entryId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      setDeletingId(entryId);
      await deleteJournalEntry(user.uid, entryId);
      setDeleteConfirmId(null);
    } catch (err) {
      console.error('Failed to delete entry:', err);
    } finally {
      setDeletingId(null);
    }
  };

  const handleExportMarkdown = (entry: JournalEntry, e: React.MouseEvent) => {
    e.stopPropagation();
    const mdContent = `# ${entry.title}
*Category: ${entry.category} | Created: ${new Date(entry.createdAt).toLocaleString()}*

## Executive Summary
${entry.summary}

## Tags
${entry.tags.join(', ')}

---

## Reflection Dialogue
${entry.messages
  .map(
    (m) =>
      `### ${m.role === 'user' ? 'User' : 'Gemini 3.6 Flash'} (${new Date(m.timestamp).toLocaleTimeString()})\n\n${m.content}\n`
  )
  .join('\n---\n\n')}
`;

    const blob = new Blob([mdContent], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${entry.title.toLowerCase().replace(/[^a-z0-9]/g, '_')}_reflection.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 flex flex-col gap-6">
      {/* Header & Filter Controls */}
      <div className="bg-white rounded-2xl p-5 border border-stone-200 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-stone-900 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-stone-700" />
            <span>Reflection History</span>
            <span className="text-xs font-mono font-normal bg-stone-100 text-stone-700 px-2 py-0.5 rounded-md">
              {entries.length} {entries.length === 1 ? 'Entry' : 'Entries'}
            </span>
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            Encrypted and isolated in your private Firestore path.
          </p>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          {/* Search bar */}
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              id="history-search-input"
              type="text"
              placeholder="Search entries or tags..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="text-xs sm:text-sm bg-stone-50 border border-stone-200 rounded-xl pl-9 pr-3 py-1.5 focus:outline-none focus:ring-1 focus:ring-stone-400 focus:bg-white text-stone-900 w-48 sm:w-64"
            />
          </div>

          <button
            id="history-new-entry-btn"
            onClick={onNewEntry}
            className="px-3.5 py-1.5 text-xs sm:text-sm font-medium bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors shadow-xs"
          >
            + New Reflection
          </button>
        </div>
      </div>

      {/* Category Pills */}
      {categories.length > 1 && (
        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <span className="text-xs font-semibold text-stone-400 flex items-center gap-1 shrink-0">
            <Filter className="w-3 h-3" />
            Category:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1 rounded-xl text-xs font-medium capitalize transition-all border ${
                selectedCategory === cat
                  ? 'bg-stone-900 text-white border-stone-900 shadow-xs'
                  : 'bg-white text-stone-600 border-stone-200 hover:bg-stone-50'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      )}

      {/* Entries List */}
      {filteredEntries.length === 0 ? (
        <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center flex flex-col items-center justify-center shadow-xs">
          <div className="w-12 h-12 rounded-2xl bg-stone-100 text-stone-400 flex items-center justify-center mb-4">
            <BookOpen className="w-6 h-6" />
          </div>
          <h3 className="font-bold text-stone-900 text-base">
            {searchQuery || selectedCategory !== 'all'
              ? 'No matching reflection entries'
              : 'No reflection entries yet'}
          </h3>
          <p className="text-xs sm:text-sm text-stone-500 mt-1 mb-6 max-w-sm">
            {searchQuery || selectedCategory !== 'all'
              ? 'Try changing your search terms or selecting a different category filter.'
              : 'Start your first conversational reflection session with Gemini 3.6 Flash.'}
          </p>
          <button
            onClick={onNewEntry}
            className="px-4 py-2 text-xs sm:text-sm font-semibold bg-stone-900 text-white rounded-xl hover:bg-stone-800 transition-colors shadow-xs flex items-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Create First Reflection</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredEntries.map((entry) => (
            <div
              key={entry.id}
              onClick={() => onSelectEntry(entry)}
              className="bg-white rounded-2xl border border-stone-200 p-5 hover:border-stone-400 hover:shadow-xs transition-all cursor-pointer flex flex-col gap-3 group"
            >
              <div className="flex items-start justify-between gap-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <h3 className="font-bold text-stone-900 text-base group-hover:text-amber-700 transition-colors">
                      {entry.title}
                    </h3>
                    <span className="px-2 py-0.5 rounded-md bg-stone-100 text-stone-700 text-[11px] font-medium">
                      {entry.category || 'Personal Growth'}
                    </span>
                    <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 text-[11px] font-medium border border-amber-200">
                      {entry.mode || 'reflection'}
                    </span>
                  </div>

                  <p className="text-xs sm:text-sm text-stone-600 line-clamp-2 leading-relaxed">
                    {entry.summary || entry.messages[0]?.content}
                  </p>
                </div>

                {/* Entry Actions */}
                <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
                  <button
                    title="Export Markdown"
                    onClick={(e) => handleExportMarkdown(entry, e)}
                    className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100 transition-colors"
                  >
                    <Download className="w-4 h-4" />
                  </button>

                  {deleteConfirmId === entry.id ? (
                    <div className="flex items-center gap-1 bg-rose-50 p-1 rounded-lg border border-rose-200">
                      <span className="text-[10px] font-semibold text-rose-700 px-1">Delete?</span>
                      <button
                        onClick={(e) => handleDelete(entry.id, e)}
                        disabled={deletingId === entry.id}
                        className="px-2 py-0.5 bg-rose-600 text-white rounded text-[10px] font-semibold hover:bg-rose-700 disabled:opacity-50"
                      >
                        Yes
                      </button>
                      <button
                        onClick={() => setDeleteConfirmId(null)}
                        className="px-1.5 py-0.5 text-stone-600 rounded text-[10px] hover:bg-stone-200"
                      >
                        No
                      </button>
                    </div>
                  ) : (
                    <button
                      title="Delete Entry"
                      onClick={() => setDeleteConfirmId(entry.id)}
                      className="p-1.5 text-stone-400 hover:text-rose-600 rounded-lg hover:bg-stone-100 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  )}
                </div>
              </div>

              {/* Tags & Meta Footer */}
              <div className="flex items-center justify-between gap-2 pt-2 border-t border-stone-100 text-xs text-stone-400 flex-wrap">
                <div className="flex items-center gap-1.5 flex-wrap">
                  {entry.tags &&
                    entry.tags.map((t, idx) => (
                      <span
                        key={idx}
                        className="inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-stone-50 border border-stone-200 text-stone-600 text-[10px]"
                      >
                        <Tag className="w-2.5 h-2.5 text-stone-400" />
                        {t}
                      </span>
                    ))}
                </div>

                <div className="flex items-center gap-3 text-[11px] shrink-0">
                  <span className="flex items-center gap-1 text-stone-500">
                    <MessageSquare className="w-3 h-3" />
                    {entry.messages?.length || 0} turns
                  </span>
                  <span className="flex items-center gap-1 text-stone-400">
                    <Calendar className="w-3 h-3" />
                    {new Date(entry.createdAt).toLocaleDateString(undefined, {
                      month: 'short',
                      day: 'numeric',
                      year: 'numeric',
                    })}
                  </span>
                  <span className="text-amber-700 font-medium group-hover:translate-x-0.5 transition-transform flex items-center gap-0.5">
                    View & Resume &rarr;
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
