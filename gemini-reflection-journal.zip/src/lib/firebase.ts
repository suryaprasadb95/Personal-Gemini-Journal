import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  doc,
  setDoc,
  getDocs,
  getDoc,
  deleteDoc,
  query,
  orderBy,
  onSnapshot
} from 'firebase/firestore';
import firebaseConfigData from '../../firebase-applet-config.json';
import { JournalEntry, InteractionLog, UserProfile, KnowledgeDocument, RAGSettings } from '../types';

// Initialize Firebase App
const firebaseConfig = {
  projectId: firebaseConfigData.projectId,
  appId: firebaseConfigData.appId,
  apiKey: firebaseConfigData.apiKey,
  authDomain: firebaseConfigData.authDomain,
  storageBucket: firebaseConfigData.storageBucket,
  messagingSenderId: firebaseConfigData.messagingSenderId,
};

const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();
googleProvider.setCustomParameters({ prompt: 'select_account' });

export const db = firebaseConfigData.firestoreDatabaseId
  ? getFirestore(app, firebaseConfigData.firestoreDatabaseId)
  : getFirestore(app);

// Zero-Crash Payload Hygiene: Strip undefined values strictly
export function stripUndefined<T extends Record<string, any>>(obj: T): T {
  const cleaned: Record<string, any> = {};
  for (const key in obj) {
    if (Object.prototype.hasOwnProperty.call(obj, key)) {
      const val = obj[key];
      if (val !== undefined) {
        if (val !== null && typeof val === 'object' && !Array.isArray(val) && !((val as object) instanceof Date)) {
          cleaned[key] = stripUndefined(val);
        } else if (Array.isArray(val)) {
          cleaned[key] = val.map((item: unknown) =>
            item !== null && typeof item === 'object' && !((item as object) instanceof Date)
              ? stripUndefined(item as Record<string, any>)
              : item
          );
        } else {
          cleaned[key] = val;
        }
      }
    }
  }
  return cleaned as T;
}

// User-Isolated Persistence Operations
export async function saveJournalEntry(userId: string, entry: JournalEntry): Promise<void> {
  if (!userId) throw new Error('User ID is required to persist journal entry.');
  const entryRef = doc(db, 'users', userId, 'entries', entry.id);
  const cleanPayload = stripUndefined({
    ...entry,
    userId,
    updatedAt: new Date().toISOString(),
  });
  await setDoc(entryRef, cleanPayload, { merge: true });
}

export async function saveInteractionLog(userId: string, log: InteractionLog): Promise<void> {
  if (!userId) throw new Error('User ID is required to log interaction.');
  const logRef = doc(db, 'users', userId, 'interactions', log.id);
  const cleanPayload = stripUndefined({
    ...log,
    userId,
    createdAt: log.createdAt || new Date().toISOString(),
  });
  await setDoc(logRef, cleanPayload);
}

export async function fetchUserEntries(userId: string): Promise<JournalEntry[]> {
  if (!userId) return [];
  const entriesRef = collection(db, 'users', userId, 'entries');
  const q = query(entriesRef, orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((docSnap) => docSnap.data() as JournalEntry);
}

export function subscribeToUserEntries(
  userId: string,
  onUpdate: (entries: JournalEntry[]) => void,
  onError?: (err: Error) => void
) {
  if (!userId) return () => {};
  const entriesRef = collection(db, 'users', userId, 'entries');
  const q = query(entriesRef, orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const entries = snapshot.docs.map((docSnap) => docSnap.data() as JournalEntry);
      onUpdate(entries);
    },
    (error) => {
      console.error('Error listening to user entries:', error);
      if (onError) onError(error);
    }
  );
}

export async function deleteJournalEntry(userId: string, entryId: string): Promise<void> {
  if (!userId || !entryId) throw new Error('User ID and Entry ID are required to delete entry.');
  const entryRef = doc(db, 'users', userId, 'entries', entryId);
  await deleteDoc(entryRef);
}

// Knowledge Documents & RAG Grounding Storage
export async function saveKnowledgeDoc(userId: string, docData: KnowledgeDocument): Promise<void> {
  if (!userId) throw new Error('User ID is required to save knowledge document.');
  const docRef = doc(db, 'users', userId, 'knowledge_docs', docData.id);
  const cleanPayload = stripUndefined({
    ...docData,
    userId,
    updatedAt: new Date().toISOString(),
  });
  await setDoc(docRef, cleanPayload, { merge: true });
}

export async function fetchKnowledgeDocs(userId: string): Promise<KnowledgeDocument[]> {
  if (!userId) return [];
  const colRef = collection(db, 'users', userId, 'knowledge_docs');
  const q = query(colRef, orderBy('createdAt', 'desc'));
  const snapshot = await getDocs(q);
  return snapshot.docs.map((docSnap) => docSnap.data() as KnowledgeDocument);
}

export function subscribeToKnowledgeDocs(
  userId: string,
  onUpdate: (docs: KnowledgeDocument[]) => void,
  onError?: (err: Error) => void
) {
  if (!userId) return () => {};
  const colRef = collection(db, 'users', userId, 'knowledge_docs');
  const q = query(colRef, orderBy('createdAt', 'desc'));
  return onSnapshot(
    q,
    (snapshot) => {
      const docs = snapshot.docs.map((docSnap) => docSnap.data() as KnowledgeDocument);
      onUpdate(docs);
    },
    (error) => {
      console.error('Error listening to knowledge docs:', error);
      if (onError) onError(error);
    }
  );
}

export async function deleteKnowledgeDoc(userId: string, docId: string): Promise<void> {
  if (!userId || !docId) throw new Error('User ID and Doc ID are required to delete knowledge doc.');
  const docRef = doc(db, 'users', userId, 'knowledge_docs', docId);
  await deleteDoc(docRef);
}

// User RAG Preferences
export async function saveRAGSettings(userId: string, settings: RAGSettings): Promise<void> {
  if (!userId) return;
  const settingsRef = doc(db, 'users', userId, 'settings', 'rag');
  await setDoc(settingsRef, stripUndefined(settings), { merge: true });
}

export async function fetchRAGSettings(userId: string): Promise<RAGSettings | null> {
  if (!userId) return null;
  const settingsRef = doc(db, 'users', userId, 'settings', 'rag');
  const snap = await getDoc(settingsRef);
  if (snap.exists()) {
    return snap.data() as RAGSettings;
  }
  return null;
}


export async function signInWithGoogle(): Promise<UserProfile> {
  const result = await signInWithPopup(auth, googleProvider);
  const user = result.user;
  
  // Update or set user profile metadata doc in isolated path
  const userDocRef = doc(db, 'users', user.uid);
  await setDoc(
    userDocRef,
    stripUndefined({
      uid: user.uid,
      email: user.email,
      displayName: user.displayName,
      photoURL: user.photoURL,
      lastLoginAt: new Date().toISOString(),
    }),
    { merge: true }
  );

  return {
    uid: user.uid,
    email: user.email,
    displayName: user.displayName,
    photoURL: user.photoURL,
  };
}

export async function signOutUser(): Promise<void> {
  await firebaseSignOut(auth);
}
