import React, { useState, useEffect } from 'react';
import { onAuthStateChanged, User } from 'firebase/auth';
import {
  auth,
  signInWithGoogle,
  signOutUser,
  subscribeToUserEntries,
  subscribeToKnowledgeDocs
} from './lib/firebase';
import { JournalEntry, UserProfile, KnowledgeDocument } from './types';
import { Navbar } from './components/Navbar';
import { LandingPage } from './components/LandingPage';
import { ReflectionStudio } from './components/ReflectionStudio';
import { HistoryViewer } from './components/HistoryViewer';
import { KnowledgeVault } from './components/KnowledgeVault';
import { Sparkles, Shield, AlertCircle } from 'lucide-react';

export default function App() {
  const [currentUser, setCurrentUser] = useState<UserProfile | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  const [activeView, setActiveView] = useState<'studio' | 'knowledge' | 'history'>('studio');
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [knowledgeDocs, setKnowledgeDocs] = useState<KnowledgeDocument[]>([]);
  const [activeEntry, setActiveEntry] = useState<JournalEntry | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);

  // Monitor Firebase Auth State
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user: User | null) => {
      if (user) {
        setCurrentUser({
          uid: user.uid,
          email: user.email,
          displayName: user.displayName,
          photoURL: user.photoURL,
        });
      } else {
        setCurrentUser(null);
        setEntries([]);
        setKnowledgeDocs([]);
        setActiveEntry(null);
      }
      setAuthLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Subscribe to isolated user journal entries in Firestore
  useEffect(() => {
    if (!currentUser) return;

    const unsubscribe = subscribeToUserEntries(
      currentUser.uid,
      (userEntries) => {
        setEntries(userEntries);
      },
      (error) => {
        console.error('Firestore subscription error:', error);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  // Subscribe to isolated knowledge documents in Firestore
  useEffect(() => {
    if (!currentUser) return;

    const unsubscribe = subscribeToKnowledgeDocs(
      currentUser.uid,
      (docs) => {
        setKnowledgeDocs(docs);
      },
      (error) => {
        console.error('Firestore knowledge subscription error:', error);
      }
    );

    return () => unsubscribe();
  }, [currentUser]);

  const handleSignIn = async () => {
    try {
      setAuthError(null);
      await signInWithGoogle();
    } catch (err: any) {
      console.error('Sign-in error:', err);
      setAuthError(err?.message || 'Failed to sign in. Please try again.');
      throw err;
    }
  };

  const handleSignOut = async () => {
    try {
      await signOutUser();
      setActiveView('studio');
      setActiveEntry(null);
    } catch (err: any) {
      console.error('Sign-out error:', err);
    }
  };

  const handleStartNewReflection = () => {
    setActiveEntry(null);
    setActiveView('studio');
  };

  const handleSelectEntryToInspect = (entry: JournalEntry) => {
    setActiveEntry(entry);
    setActiveView('studio');
  };

  const handleEntrySaved = (savedEntry: JournalEntry) => {
    setActiveEntry(savedEntry);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 rounded-2xl bg-stone-900 text-amber-300 flex items-center justify-center shadow-md animate-pulse">
            <Sparkles className="w-5 h-5" />
          </div>
          <span className="text-sm font-medium text-stone-600">Initializing Gemini Reflection...</span>
        </div>
      </div>
    );
  }

  if (!currentUser) {
    return <LandingPage onSignIn={handleSignIn} />;
  }

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 flex flex-col justify-between">
      <Navbar
        user={currentUser}
        onSignOut={handleSignOut}
        onNewReflection={handleStartNewReflection}
        activeView={activeView}
        setActiveView={setActiveView}
        entryCount={entries.length}
        docCount={knowledgeDocs.length}
      />

      {authError && (
        <div className="max-w-5xl mx-auto px-4 sm:px-6 pt-4 w-full">
          <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            <span>{authError}</span>
          </div>
        </div>
      )}

      <main className="flex-1">
        {activeView === 'studio' ? (
          <ReflectionStudio
            user={currentUser}
            activeEntry={activeEntry}
            knowledgeDocs={knowledgeDocs}
            onEntrySaved={handleEntrySaved}
            onStartNew={handleStartNewReflection}
            onNavigateToVault={() => setActiveView('knowledge')}
          />
        ) : activeView === 'knowledge' ? (
          <KnowledgeVault
            user={currentUser}
            documents={knowledgeDocs}
            onDocumentsChange={(docs) => setKnowledgeDocs(docs)}
            onNavigateToStudio={() => setActiveView('studio')}
          />
        ) : (
          <HistoryViewer
            user={currentUser}
            entries={entries}
            onSelectEntry={handleSelectEntryToInspect}
            onNewEntry={handleStartNewReflection}
          />
        )}
      </main>

      <footer className="border-t border-stone-200 py-4 bg-white text-center text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <span>Gemini Reflection & RAG Knowledge Vault &copy; {new Date().getFullYear()}</span>
          <span className="flex items-center gap-1 text-emerald-700 font-medium">
            <Shield className="w-3.5 h-3.5" />
            Isolated Firestore Paths: /users/{currentUser.uid.slice(0, 8)}... (entries & knowledge)
          </span>
        </div>
      </footer>
    </div>
  );
}
